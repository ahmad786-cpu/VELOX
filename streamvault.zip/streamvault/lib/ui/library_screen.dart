// lib/ui/library_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';

import '../providers/download_provider.dart';
import '../core/constants.dart';
import '../core/theme.dart';
import 'player_screen.dart';

class LibraryScreen extends ConsumerWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasks = ref.watch(downloadQueueProvider);
    final completed = tasks
        .where((t) => t.status == AppDownloadStatus.complete)
        .toList();
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('YOUR VAULT',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2.0)),
        actions: [
          if (completed.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppConstants.accentIndigo.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(100),
                    border: Border.all(
                        color: AppConstants.accentIndigo.withOpacity(0.3)),
                  ),
                  child: Text(
                    '${completed.length} videos',
                    style: const TextStyle(
                        fontSize: 11,
                        color: AppConstants.accentIndigo,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Filter chips (static for now, can be wired to state later)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: const [
                  _FilterChip(label: 'All', isActive: true),
                  _FilterChip(label: 'Videos'),
                  _FilterChip(label: 'Audio'),
                ],
              ),
            ),
            const SizedBox(height: 32),

            Text('Downloaded',
                style: textTheme.headlineMedium
                    ?.copyWith(color: AppConstants.primary)),
            const SizedBox(height: 16),

            if (completed.isEmpty)
              const _EmptyVaultState()
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 0.85,
                ),
                itemCount: completed.length,
                itemBuilder: (ctx, i) =>
                    _VaultVideoCard(task: completed[i]),
              ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isActive;
  const _FilterChip({required this.label, this.isActive = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        gradient: isActive ? AppConstants.liquidGradient : null,
        color: isActive ? null : const Color(0x1AFFFFFF),
        borderRadius: BorderRadius.circular(100),
        border: isActive ? null : Border.all(color: Colors.white10),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isActive ? Colors.white : Colors.white60,
          fontWeight: FontWeight.bold,
          fontSize: 13,
        ),
      ),
    );
  }
}

class _VaultVideoCard extends StatelessWidget {
  final DownloadTaskInfo task;
  const _VaultVideoCard({required this.task});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (task.localPath != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PlayerScreen(
                  filePath: task.localPath!, title: task.title),
            ),
          );
        }
      },
      child: GlassPanel(
        borderRadius: 24,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: CachedNetworkImage(
                      imageUrl: task.thumbnailUrl,
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => Container(
                        color: AppConstants.surfaceContainer,
                        child: const Icon(Icons.movie,
                            color: Colors.white24, size: 32),
                      ),
                    ),
                  ),
                  // Overlay
                  Container(
                    decoration: const BoxDecoration(
                      gradient: RadialGradient(
                        colors: [Color(0x996366F1), Colors.transparent],
                        radius: 0.7,
                      ),
                    ),
                  ),
                  const Center(
                    child: Icon(Icons.play_circle_filled_rounded,
                        color: Colors.white, size: 36),
                  ),
                ],
              ),
            ),

            // Info
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color:
                              AppConstants.accentCyan.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          'MP4',
                          style: TextStyle(
                              fontSize: 9,
                              color: AppConstants.accentCyan,
                              fontWeight: FontWeight.w800),
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Icon(Icons.check_circle_rounded,
                          color: Colors.greenAccent, size: 12),
                      const SizedBox(width: 3),
                      const Text('Saved',
                          style: TextStyle(
                              fontSize: 10, color: Colors.greenAccent)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyVaultState extends StatelessWidget {
  const _EmptyVaultState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Opacity(
        opacity: 0.4,
        child: Column(
          children: [
            const SizedBox(height: 48),
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    AppConstants.accentIndigo.withOpacity(0.2),
                    AppConstants.accentCyan.withOpacity(0.2),
                  ],
                ),
                border: Border.all(color: Colors.white10),
              ),
              child: const Icon(Icons.video_library_rounded,
                  size: 72, color: AppConstants.accentIndigo),
            ),
            const SizedBox(height: 24),
            const Text('Vault is empty',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Your cinematic collection starts here.',
                style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 48),
          ],
        ),
      ),
    );
  }
}
