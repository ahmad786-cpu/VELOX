// lib/ui/settings_screen.dart
import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../core/theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('SETTINGS',
            style: TextStyle(
                fontWeight: FontWeight.w900, letterSpacing: 2.0)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Profile card
            GlassPanel(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Stack(
                    children: [
                      Container(
                        width: 80, height: 80,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: AppConstants.surfaceContainer,
                        ),
                        child: const Icon(Icons.person_rounded,
                            color: Colors.white38, size: 40),
                      ),
                      Positioned(
                        bottom: -4, right: -4,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            gradient: AppConstants.liquidGradient,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.stars_rounded,
                              size: 16, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('StreamVault User',
                            style: textTheme.headlineMedium
                                ?.copyWith(fontSize: 20)),
                        Text('Free Plan', style: textTheme.labelMedium),
                        const SizedBox(height: 8),
                        TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom(
                            backgroundColor:
                                Colors.white.withOpacity(0.05),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100)),
                            minimumSize: Size.zero,
                            tapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                          child: const Text('Manage Account',
                              style: TextStyle(
                                  color: AppConstants.accentCyan,
                                  fontSize: 12)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Downloads section
            _SettingsGroup(
              title: 'DOWNLOADS',
              items: [
                const _SettingsTile(
                    icon: Icons.high_quality_rounded,
                    label: 'Default Quality',
                    value: 'Best Available'),
                const _SettingsTile(
                    icon: Icons.folder_open_rounded,
                    label: 'Download Folder',
                    value: '/Documents/StreamVault'),
                _SettingsTile(
                  icon: Icons.wifi_rounded,
                  label: 'Wi-Fi Only',
                  trailing: Switch(
                      value: false,
                      onChanged: (_) {},
                      activeColor: AppConstants.accentIndigo),
                ),
                _SettingsTile(
                  icon: Icons.play_circle_outline_rounded,
                  label: 'Auto-resume Downloads',
                  trailing: Switch(
                      value: true,
                      onChanged: (_) {},
                      activeColor: AppConstants.accentIndigo),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Appearance section
            _SettingsGroup(
              title: 'APPEARANCE',
              items: [
                _SettingsTile(
                  icon: Icons.dark_mode_outlined,
                  label: 'Dark Mode',
                  trailing: Switch(
                      value: true,
                      onChanged: (_) {},
                      activeColor: AppConstants.accentIndigo),
                ),
                const _SettingsTile(
                    icon: Icons.palette_outlined,
                    label: 'Accent Color',
                    value: 'Electric Indigo'),
              ],
            ),
            const SizedBox(height: 24),

            // Server section
            _SettingsGroup(
              title: 'BACKEND',
              items: [
                _SettingsTile(
                  icon: Icons.dns_rounded,
                  label: 'API Server',
                  value: AppConstants.apiBaseUrl,
                ),
                const _SettingsTile(
                    icon: Icons.info_outline_rounded,
                    label: 'Version',
                    value: '1.0.0'),
              ],
            ),
            const SizedBox(height: 24),

            // About
            _SettingsGroup(
              title: 'ABOUT',
              items: [
                const _SettingsTile(
                    icon: Icons.privacy_tip_outlined,
                    label: 'Privacy Policy'),
                const _SettingsTile(
                    icon: Icons.description_outlined,
                    label: 'Terms of Service'),
                const _SettingsTile(
                    icon: Icons.bug_report_outlined,
                    label: 'Report a Bug'),
              ],
            ),
            const SizedBox(height: 32),

            // Legal disclaimer
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.08),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                    color: Colors.orange.withOpacity(0.25)),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.warning_amber_rounded,
                      color: Colors.orange, size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Only download content you have the right to download. '
                      'Respect copyright and each platform\'s terms of service.',
                      style: TextStyle(
                          color: Colors.orange,
                          fontSize: 12,
                          height: 1.5),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 120),
          ],
        ),
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  final String title;
  final List<Widget> items;
  const _SettingsGroup({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 10),
          child: Text(title,
              style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  color: AppConstants.accentIndigo)),
        ),
        GlassPanel(
          borderRadius: 20,
          child: Column(
            children: List.generate(items.length, (i) {
              final isLast = i == items.length - 1;
              return Column(
                children: [
                  items[i],
                  if (!isLast)
                    const Divider(
                        height: 1,
                        indent: 56,
                        color: Colors.white10),
                ],
              );
            }),
          ),
        ),
      ],
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? value;
  final Widget? trailing;

  const _SettingsTile({
    required this.icon,
    required this.label,
    this.value,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: Colors.white60, size: 22),
      title: Text(label,
          style: const TextStyle(fontSize: 15, color: Colors.white)),
      trailing: trailing ??
          (value != null
              ? Text(value!,
                  style: const TextStyle(
                      color: Colors.white38, fontSize: 13))
              : const Icon(Icons.chevron_right_rounded,
                  color: Colors.white24)),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      onTap: () {},
    );
  }
}
