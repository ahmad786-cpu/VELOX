// lib/services/extractor_service.dart
import 'package:dio/dio.dart';
import '../models/video_model.dart';
import '../core/constants.dart';

class ExtractorService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: AppConstants.apiBaseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 60),
    ),
  );

  Future<VideoModel?> fetchVideoMetadata(String url) async {
    try {
      final response = await _dio.get(
        '/extract',
        queryParameters: {'url': url},
      );
      final data = response.data as Map<String, dynamic>;

      // ── top-level audio URL (best separate audio stream) ──────────────────
      final String? topAudioUrl = data['audio_url'] as String?;

      // ── build resolution list ─────────────────────────────────────────────
      final rawResolutions = (data['resolutions'] as List?) ?? [];
      final resolutions = <VideoResolution>[];

      for (final r in rawResolutions) {
        final res = r as Map<String, dynamic>;

        // is_muxed comes from the backend and is now reliable:
        //   true  → single file with audio+video embedded (≤ 720p YouTube)
        //   false → video-only adaptive stream; needs FFmpeg merge
        final bool isMuxed = res['is_muxed'] == true;

        // For adaptive streams the backend attaches the best audio URL directly
        // on the resolution entry; fall back to the top-level audio_url.
        final String? audioUrl =
            (res['audio_url'] as String?) ?? (isMuxed ? null : topAudioUrl);

        resolutions.add(VideoResolution(
          label: (res['quality'] as String?) ?? '${res['height']}p',
          height: (res['height'] as num?)?.round() ?? 0,
          videoStreamUrl: res['video_url'] as String?,
          audioStreamUrl: audioUrl,
          isMuxed: isMuxed,
          isHdr: res['is_hdr'] == true,
          isHfr: res['is_hfr'] == true,
          ext: (res['ext'] as String?) ?? 'mp4',
        ));
      }

      // Sort highest quality first (backend already does this, but be safe)
      resolutions.sort((a, b) => b.height.compareTo(a.height));

      return VideoModel(
        id: (data['id'] as String?) ?? '',
        title: (data['title'] as String?) ?? 'Unknown Title',
        author: (data['author'] as String?) ?? 'Unknown',
        thumbnailUrl: (data['thumbnail'] as String?) ?? '',
        duration: Duration(
          seconds: (data['duration'] as num?)?.round() ?? 0,
        ),
        availableResolutions: resolutions,
      );
    } on DioException catch (e) {
      final detail = (e.response?.data as Map?)?['detail'];
      throw Exception(detail ?? e.message ?? 'Network error');
    } catch (e) {
      throw Exception('Unexpected error: $e');
    }
  }

  void dispose() => _dio.close();
}
