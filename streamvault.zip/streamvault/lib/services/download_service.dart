// lib/services/download_service.dart
import 'dart:isolate';
import 'dart:ui';

import 'package:flutter/foundation.dart' show kIsWeb, debugPrint;
import 'package:dio/dio.dart';
import 'package:flutter_downloader/flutter_downloader.dart' as fd;
import 'package:ffmpeg_kit_flutter_full_gpl/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_full_gpl/return_code.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'dart:io' as io;

import '../core/constants.dart';
import 'web_download_stub.dart'
    if (dart.library.html) 'web_download_web.dart';

class DownloadService {
  static final DownloadService _instance = DownloadService._internal();
  factory DownloadService() => _instance;
  DownloadService._internal();

  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(minutes: 10),
  ));

  final Map<String, String> _taskUrls = {};
  final Map<String, CancelToken> _cancelTokens = {};

  bool get _isMobile =>
      !kIsWeb && (io.Platform.isAndroid || io.Platform.isIOS);

  // ── Init ──────────────────────────────────────────────────────────────────

  Future<void> init() async {
    if (kIsWeb || !_isMobile) return;
    try {
      await fd.FlutterDownloader.initialize(debug: false, ignoreSsl: true);
      fd.FlutterDownloader.registerCallback(_downloaderCallback);
      debugPrint('[DownloadService] FlutterDownloader ready');
    } catch (e) {
      debugPrint('[DownloadService] FlutterDownloader init error: $e');
    }
  }

  @pragma('vm:entry-point')
  static void _downloaderCallback(String id, int status, int progress) {
    final SendPort? port =
        IsolateNameServer.lookupPortByName('downloader_send_port');
    port?.send([id, status, progress]);
  }

  // ── Public API ────────────────────────────────────────────────────────────

  void setTaskUrl(String id, String url) => _taskUrls[id] = url;

  Future<String?> enqueueDownload({
    required String url,
    required String fileName,
    bool isMuxed = true,
    String? audioUrl,
    void Function(int progress, int downloaded, int total)? onProgress,
  }) async {
    if (kIsWeb) {
      triggerWebDownload(url, fileName);
      return 'web_download_started';
    }

    final savedDir = await getDownloadPath();
    final outputPath = p.join(savedDir, fileName);

    if (isMuxed) {
      if (_isMobile) {
        final taskId = await fd.FlutterDownloader.enqueue(
          url: url,
          savedDir: savedDir,
          fileName: fileName,
          showNotification: true,
          openFileFromNotification: false,
          saveInPublicStorage: false,
        );
        if (taskId != null) setTaskUrl(taskId, url);
        return taskId;
      } else {
        setTaskUrl(outputPath, url);
        _startDesktopDownload(url, outputPath, onProgress: onProgress);
        return outputPath;
      }
    } else {
      if (audioUrl == null) {
        debugPrint('[DownloadService] adaptive: audioUrl is null');
        return null;
      }
      return _downloadAndMux(
        videoUrl: url,
        audioUrl: audioUrl,
        outputPath: outputPath,
        savedDir: savedDir,
        onProgress: onProgress,
      );
    }
  }

  Future<void> pause(String id) async {
    if (kIsWeb) return;
    if (_isMobile) {
      await fd.FlutterDownloader.pause(taskId: id);
    } else {
      _cancelTokens[id]?.cancel('pause');
    }
  }

  Future<void> resume(String id,
      {void Function(int, int, int)? onProgress}) async {
    if (kIsWeb) return;
    if (_isMobile) {
      await fd.FlutterDownloader.resume(taskId: id);
    } else {
      final url = _taskUrls[id];
      if (url != null) _startDesktopDownload(url, id, onProgress: onProgress);
    }
  }

  Future<void> cancel(String id) async {
    if (kIsWeb) return;
    _cancelTokens[id]?.cancel('cancel');
    _cancelTokens.remove(id);
    if (_isMobile) {
      await fd.FlutterDownloader.cancel(taskId: id);
    }
  }

  Future<String> getDownloadPath() async {
    if (kIsWeb) return '';
    final base = await getApplicationDocumentsDirectory();
    final dir = io.Directory(p.join(base.path, AppConstants.downloadDirName));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir.path;
  }

  // ── Desktop range-resume streaming ───────────────────────────────────────

  Future<String?> _startDesktopDownload(
    String url,
    String outputPath, {
    void Function(int, int, int)? onProgress,
  }) async {
    final cancelToken = CancelToken();
    _cancelTokens[outputPath] = cancelToken;

    try {
      final file = io.File(outputPath);
      final currentSize = await file.exists() ? await file.length() : 0;

      Response<ResponseBody> response;
      try {
        response = await _dio.get<ResponseBody>(
          url,
          options: Options(
            responseType: ResponseType.stream,
            headers:
                currentSize > 0 ? {'Range': 'bytes=$currentSize-'} : null,
          ),
          cancelToken: cancelToken,
        );
      } on DioException catch (e) {
        if (e.response?.statusCode == 416) {
          await file.writeAsBytes([]);
          response = await _dio.get<ResponseBody>(
            url,
            options: Options(responseType: ResponseType.stream),
            cancelToken: cancelToken,
          );
        } else {
          rethrow;
        }
      }

      final cl = int.tryParse(
              response.headers.value('content-length') ?? '') ??
          -1;
      final totalBytes = cl == -1 ? -1 : cl + currentSize;
      final raf = await file.open(
          mode: currentSize > 0 ? io.FileMode.append : io.FileMode.write);
      int downloaded = currentSize;

      await for (final chunk in response.data!.stream) {
        await raf.writeFrom(chunk);
        downloaded += chunk.length;
        if (totalBytes > 0) {
          onProgress?.call(
            (downloaded / totalBytes * 100).clamp(0, 100).toInt(),
            downloaded,
            totalBytes,
          );
        }
      }
      await raf.close();
      _cancelTokens.remove(outputPath);
      return outputPath;
    } on DioException catch (e) {
      _cancelTokens.remove(outputPath);
      if (CancelToken.isCancel(e)) return outputPath; // resumable
      debugPrint('[DownloadService] error: $e');
      return null;
    } catch (e) {
      _cancelTokens.remove(outputPath);
      debugPrint('[DownloadService] unexpected: $e');
      return null;
    }
  }

  // ── FFmpeg mux ────────────────────────────────────────────────────────────

  Future<String?> _downloadAndMux({
    required String videoUrl,
    required String audioUrl,
    required String outputPath,
    required String savedDir,
    void Function(int, int, int)? onProgress,
  }) async {
    final videoTmp = p.join(savedDir, '_v_${p.basename(outputPath)}');
    final audioTmp = p.join(savedDir, '_a_${p.basename(outputPath)}');
    final cancelToken = CancelToken();
    _cancelTokens[outputPath] = cancelToken;

    try {
      debugPrint('[DownloadService] Downloading video stream…');
      await _dio.download(videoUrl, videoTmp,
          cancelToken: cancelToken,
          onReceiveProgress: (r, t) {
        if (t > 0) onProgress?.call((r / t * 80).toInt(), r, t);
      });

      debugPrint('[DownloadService] Downloading audio stream…');
      await _dio.download(audioUrl, audioTmp,
          cancelToken: cancelToken,
          onReceiveProgress: (r, t) {
        if (t > 0) onProgress?.call(80 + (r / t * 15).toInt(), r, t);
      });

      _cancelTokens.remove(outputPath);

      debugPrint('[DownloadService] Muxing…');
      final vp = _fixPath(videoTmp);
      final ap = _fixPath(audioTmp);
      final op = _fixPath(outputPath);

      bool success = false;
      if (_isMobile || (!kIsWeb && io.Platform.isMacOS)) {
        // FFmpegKit (mobile + macOS)
        final session = await FFmpegKit.execute(
            '-i "$vp" -i "$ap" -c copy -map 0:v:0 -map 1:a:0 "$op" -y');
        final rc = await session.getReturnCode();
        success = ReturnCode.isSuccess(rc);
      } else {
        // System ffmpeg (Windows / Linux)
        final result = await io.Process.run('ffmpeg', [
          '-i', videoTmp, '-i', audioTmp,
          '-c', 'copy', '-map', '0:v:0', '-map', '1:a:0',
          outputPath, '-y',
        ]);
        success = result.exitCode == 0;
        if (!success) {
          debugPrint('[DownloadService] ffmpeg stderr: ${result.stderr}');
        }
      }

      if (success) {
        onProgress?.call(100, 1, 1);
        return outputPath;
      }
      return null;
    } on DioException catch (e) {
      _cancelTokens.remove(outputPath);
      if (!CancelToken.isCancel(e)) debugPrint('[DownloadService] mux Dio error: $e');
      return null;
    } finally {
      for (final tmp in [videoTmp, audioTmp]) {
        try {
          final f = io.File(tmp);
          if (await f.exists()) await f.delete();
        } catch (_) {}
      }
    }
  }

  String _fixPath(String path) =>
      (!kIsWeb && io.Platform.isWindows) ? path.replaceAll('\\', '/') : path;
}
